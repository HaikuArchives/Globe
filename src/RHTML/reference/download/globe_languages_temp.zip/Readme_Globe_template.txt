How to edit the Globe_Template.txt
-------------------------------------------------------------

First Line:

Language=		the language you are translating to
name=			your name or nick name
your@mail.address=	please write your public e-mail address

In the first line of Globe_template.txt please add your language:name:your@mail.address:

From the second line in the Globe_template.txt:

We would like you to translates the words after "="

An example:
About_Window:About=About (originally templates 2.nd line)
About_Window:About=Névjegy (editing is Hungarian Language)

When you have finished the translations, save it as your language.txt and send it to 
kesigomu@enternet.hu

Thank you for helping us!

kesigomu from Hungary

 